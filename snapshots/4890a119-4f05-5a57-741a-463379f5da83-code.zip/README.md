# Editing Dallinger code

Using the "Bartlett" skeleton from the Dallinger code to create a new experiment that is entirely different..!
